console.log("hello");
var p = document.getElementById('message');
var storage = navigator.getDeviceStorage('sdcard');
var cursor;
cursor = storage.enumerate();
cursor.onsuccess = function() {
  if (this.done)
    console.log("done");
  p.insertAdjacentHtml('beforeend', this.result.name);
};